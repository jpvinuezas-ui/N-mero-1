# Bloques HTML + script.js para datos dinámicos (MARCOR)

## Archivos incluidos
- index_kpis_news.html  → Bloques KPIs + Noticias para la portada.
- larvicultura_tabla_block.html → Tabla dinámica para Larvicultura.
- maduracion_tabla_block.html  → Tabla dinámica para Maduración.
- script.js → Menú, reveal, contadores y carga de JSON.
  *Asegúrate de enlazarlo en todas las páginas con:* 
  <script src="script.js" defer></script>

## Cómo usar
1) Copia estos archivos a la raíz del proyecto.
2) Pega el contenido de cada bloque en el lugar que corresponda dentro de tus HTML.
3) Sube/crea la carpeta /data con los JSON (kpis_home.json, larvicultura_tabla.json, maduracion_tabla.json, news.json).
4) Revisa el Deploy Preview en Netlify.

## Requisitos
- Mantener las clases CSS existentes: .kpis, .kpi, .tabla, .table-wrap, .reveal, etc.
- Mantener los IDs: #tabla-larvicultura, #tabla-maduracion, #news-list.

