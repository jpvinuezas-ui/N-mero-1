# Paquete completo: datos + bloques + script (MARCOR)

## Estructura
/
├─ data/
│  ├─ kpis_home.json
│  ├─ larvicultura_tabla.json
│  ├─ maduracion_tabla.json
│  └─ news.json
├─ blocks/
│  ├─ index_kpis_news.html
│  ├─ larvicultura_tabla_block.html
│  └─ maduracion_tabla_block.html
└─ script.js

## Cómo usar (pasos cortos)
1) Sube todo el contenido de este paquete a tu repo (rama Prueba).
2) En `index.html` inserta el bloque de `blocks/index_kpis_news.html` donde quieras KPIs+Noticias.
3) En `larvicultura.html` reemplaza la tabla por `blocks/larvicultura_tabla_block.html`.
4) En `maduracion.html` reemplaza la tabla por `blocks/maduracion_tabla_block.html`.
5) Asegúrate de tener al final de cada página:
   <script src="script.js" defer></script>
6) Haz commit y revisa el Deploy Preview de Netlify.

## Notas
- Puedes editar solo los JSON en /data para actualizar números, filas o noticias.
- Si quieres añadir links a mapas, completa `map_url` en los JSON.
- Mantén las clases CSS (.kpis, .tabla, .reveal, etc.) de tu hoja de estilos actual.
